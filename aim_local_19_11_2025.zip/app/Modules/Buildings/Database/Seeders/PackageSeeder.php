<?php

namespace App\Modules\Packages\Database\Seeders;

use App\Modules\Areas\Models\Area;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class PackageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

    }
}
